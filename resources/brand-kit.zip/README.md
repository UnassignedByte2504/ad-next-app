# Ayla Designs Brand Kit

## Contents

- **fonts/** - Brand typography (Cormorant Garamond, Nunito Sans, JetBrains Mono)
- **pdfs/** - Brand documentation

## PDF Documentation

1. **01-brand-overview.pdf** - Brand philosophy, values, and visual identity overview
2. **02-color-palette.pdf** - Complete color system with HEX, RGB, and HSL values
3. **03-typography.pdf** - Font families, type scale, and usage guidelines
4. **04-category-chips.pdf** - Product category colors and chip variants
5. **05-motion-system.pdf** - Animation tokens and motion guidelines

## Quick Reference

### Colors
- Primary (Amber): #F59E0B
- Secondary (Lavender): #A855F7
- Accent (Rose): #F43F5E
- Background: #FAFAF9 (Stone 50)

### Typography
- Headings: Cormorant Garamond
- Body: Nunito Sans
- Code: JetBrains Mono

### Brand Concept
"Magia Profesional" - Bohemian elegance meets professional design

---

Generated: 2025-12-19
Ayla Designs © 2025
